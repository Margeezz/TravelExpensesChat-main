# Starting Over

Minimal workspace. All instructions live under `Workflow/`.

Start here:
- `Workflow/MasterAgent.md` – agent rules & triggers
- `Workflow/Process.md` – phases & gates
- `Workflow/Templates/` – templates