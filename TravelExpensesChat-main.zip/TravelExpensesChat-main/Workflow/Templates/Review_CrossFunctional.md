# Review — Cross‑Functional Report

## Summary
- High: 0 | Medium: 0 | Low: 0
- Open Decisions: <list>

## Index (Epics → Requirements)
<!-- Filled by script: path and titles for navigation -->

## Persona Findings

### RE - Requirements Engineering
- Issue: <what is not good enough>
  - Why it matters: <impact>
  - Severity: High | Medium | Low
  - Owner: <name/role>
  - Evidence: <quote/line or file path>
  - Fix: <specific change in path>

### BA - Business Analysis
- Issue: <...>
  - Why it matters: <...>
  - Severity: High | Medium | Low
  - Owner: <...>
  - Evidence: <...>
  - Fix: <...>

### UX - User Experience
- Issue: <...>
  - Why it matters: <...>
  - Severity: High | Medium | Low
  - Owner: <...>
  - Evidence: <...>
  - Fix: <...>

### Sec - Security/Privacy/Compliance
- Issue: <...>
  - Why it matters: <...>
  - Severity: High | Medium | Low
  - Owner: <...>
  - Evidence: <...>
  - Fix: <...>

### Arch - Architecture/Performance/Resilience
- Issue: <...>
  - Why it matters: <...>
  - Severity: High | Medium | Low
  - Owner: <...>
  - Evidence: <...>
  - Fix: <...>

### QA - Testability/Scenarios
- Issue: <...>
  - Why it matters: <...>
  - Severity: High | Medium | Low
  - Owner: <...>
  - Evidence: <...>
  - Fix: <...>



