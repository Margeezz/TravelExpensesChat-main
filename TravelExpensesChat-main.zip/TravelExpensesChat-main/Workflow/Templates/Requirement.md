# R-<NNN> <Short title>

## Why
<1 sentence value/rule>

## Behavior
- <observable behavior 1>
- <observable behavior 2>
- <observable behavior 3>

## Scenarios (BDD)
Scenario: <short scenario title>
Given <initial state>
When <action>
Then <result>
And <result>

