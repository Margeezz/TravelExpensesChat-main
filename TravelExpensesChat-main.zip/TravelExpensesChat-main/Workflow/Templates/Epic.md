# E-<NNN> <Epic title>

## Intent
<1–2 sentences>

## In-Scope
- <item>
- <item>

## Out-of-Scope (optional)
- <item>

## Requirements
- See structure and naming in `Workflow/Conventions.md`.
- Reference list (optional):
- R-001 <short title>
- R-002 <short title>

