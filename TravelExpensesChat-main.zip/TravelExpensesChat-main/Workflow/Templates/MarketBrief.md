# Market Brief — <Topic>

## Scope

## Competitor Implementations
- <Competitor>: <how it works> (link)

## Patterns & Gaps

## Risks/Compliance Notes

## Options & Recommendation
- Option A …
- Option B …
- Recommendation: …

## Sources
- <link>

